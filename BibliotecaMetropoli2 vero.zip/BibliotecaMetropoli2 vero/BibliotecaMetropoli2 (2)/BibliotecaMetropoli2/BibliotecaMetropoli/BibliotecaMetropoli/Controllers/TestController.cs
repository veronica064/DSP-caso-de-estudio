﻿// Controllers/TestController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BibliotecaMetropoli.Data;
using BibliotecaMetropoli.Data;

namespace BibliotecaDB.Controllers
{
    public class TestController : Controller
    {
        private readonly BibliotecaMetropoliContext _context;

        public TestController(BibliotecaMetropoliContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                // Probar si la base de datos existe y puede conectarse
                var canConnect = await _context.Database.CanConnectAsync();

                if (canConnect)
                {
                    // Probar consulta simple
                    var autoresCount = await _context.Autores.CountAsync();
                    ViewBag.Message = $"✅ Conexión exitosa. Base de datos operativa. Autores en BD: {autoresCount}";
                }
                else
                {
                    ViewBag.Message = "❌ No se pudo conectar a la base de datos";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"❌ Error: {ex.Message}";
                if (ex.InnerException != null)
                {
                    ViewBag.InnerException = $"Detalles: {ex.InnerException.Message}";
                }
            }

            return View();
        }
    }
}