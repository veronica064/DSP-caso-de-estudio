﻿using Microsoft.EntityFrameworkCore;
using BibliotecaMetropoli.Models;

namespace BibliotecaMetropoli.Data
{
    
    /// Contexto de Entity Framework para la base de datos BibliotecaMetropolis
    /// Integrante 3: Especialista en Entity Framework y Modelo
    
    public class BibliotecaMetropolisDBContext : DbContext
    {
        public BibliotecaMetropolisDBContext(DbContextOptions<BibliotecaMetropolisDBContext> options) : base(options)
        {
        }

        // DbSets - Representan las tablas en la base de datos
        public DbSet<Pais> Pais { get; set; }
        public DbSet<Autor> Autor { get; set; }
        public DbSet<AutoresRecurso> AutoresRecurso { get; set; }
        public DbSet<Editorial> Editorial { get; set; }
        public DbSet<Recurso> Recurso { get; set; }
        public DbSet<TipoRecurso> TipoRecurso { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            #region Configuración de Claves Primarias Compuestas

            // Configurar la clave primaria compuesta para AutoresRecursos
            modelBuilder.Entity<AutoresRecurso>()
                .HasKey(ar => new { ar.IdRec, ar.IdAutor });

            #endregion

            #region Configuración de Relaciones

            // Relaciones de AutoresRecursos con Recurso
            modelBuilder.Entity<AutoresRecurso>()
                .HasOne(ar => ar.Recurso)
                .WithMany(r => r.AutoresRecurso)
                .HasForeignKey(ar => ar.IdRec)
                .OnDelete(DeleteBehavior.Cascade);

            // Relaciones de AutoresRecursos con Autor
            modelBuilder.Entity<AutoresRecurso>()
                .HasOne(ar => ar.Autor)
                .WithMany(a => a.AutoresRecurso)
                .HasForeignKey(ar => ar.IdAutor)
                .OnDelete(DeleteBehavior.Cascade);

            // Relación de Recurso con Pais
            modelBuilder.Entity<Recurso>()
                .HasOne(r => r.Pais)
                .WithMany(p => p.Recursos)
                .HasForeignKey(r => r.IdPais)
                .OnDelete(DeleteBehavior.Restrict);

            // Relación de Recurso con TipoRecurso
            modelBuilder.Entity<Recurso>()
                .HasOne(r => r.TipoRecurso)
                .WithMany(tr => tr.Recursos)
                .HasForeignKey(r => r.IdTipoR)
                .OnDelete(DeleteBehavior.Restrict);

            // Relación de Recurso con Editorial (Nullable para Tesis)
            modelBuilder.Entity<Recurso>()
                .HasOne(r => r.Editorial)
                .WithMany(e => e.Recursos)
                .HasForeignKey(r => r.IdEdit)
                .OnDelete(DeleteBehavior.Restrict)
                .IsRequired(false); // Permite NULL para Tesis

            #endregion

            #region Configuración de Índices

            // Índices para mejorar el rendimiento de las consultas
            modelBuilder.Entity<Recurso>()
                .HasIndex(r => r.IdPais)
                .HasDatabaseName("IX_Recurso_idPais");

            modelBuilder.Entity<Recurso>()
                .HasIndex(r => r.IdTipoR)
                .HasDatabaseName("IX_Recurso_idTipoR");

            modelBuilder.Entity<Recurso>()
                .HasIndex(r => r.IdEdit)
                .HasDatabaseName("IX_Recurso_idEdit");

            modelBuilder.Entity<AutoresRecurso>()
                .HasIndex(ar => ar.IdAutor)
                .HasDatabaseName("IX_AutoresRecursos_idAutor");

            #endregion

            #region Configuración de Valores por Defecto

            modelBuilder.Entity<AutoresRecurso>()
                .Property(ar => ar.EsPrincipal)
                .HasDefaultValue(false);

            #endregion

            #region Configuración de Propiedades de Strings

            // Pais
            modelBuilder.Entity<Pais>()
                .Property(p => p.Nombre)
                .IsRequired()
                .HasMaxLength(100);

            // Editorial
            modelBuilder.Entity<Editorial>()
                .Property(e => e.Nombre)
                .IsRequired()
                .HasMaxLength(100);

            modelBuilder.Entity<Editorial>()
                .Property(e => e.Description)
                .HasMaxLength(500);

            // TipoRecurso
            modelBuilder.Entity<TipoRecurso>()
                .Property(tr => tr.Nombre)
                .IsRequired()
                .HasMaxLength(100);

            modelBuilder.Entity<TipoRecurso>()
                .Property(tr => tr.Description)
                .HasMaxLength(500);

            // Autor
            modelBuilder.Entity<Autor>()
                .Property(a => a.Nombres)
                .IsRequired()
                .HasMaxLength(100);

            modelBuilder.Entity<Autor>()
                .Property(a => a.Apellidos)
                .IsRequired()
                .HasMaxLength(100);

            // Recurso
            modelBuilder.Entity<Recurso>()
                .Property(r => r.Titulo)
                .IsRequired()
                .HasMaxLength(255);

            modelBuilder.Entity<Recurso>()
                .Property(r => r.Edicion)
                .IsRequired()
                .HasMaxLength(50);

            modelBuilder.Entity<Recurso>()
                .Property(r => r.PalabrasBusqueda)
                .HasMaxLength(500);

            modelBuilder.Entity<Recurso>()
                .Property(r => r.Palabrasbusqueda)
                .HasMaxLength(500);

            modelBuilder.Entity<Recurso>()
                .Property(r => r.Descripcion)
                .HasMaxLength(1000);

            #endregion

            #region Mapeo de Tablas

            // Mapear los nombres de las tablas exactamente como están en SQL Server
            modelBuilder.Entity<Pais>().ToTable("Pais");
            modelBuilder.Entity<Autor>().ToTable("Autor");
            modelBuilder.Entity<AutoresRecurso>().ToTable("AutoresRecursos");
            modelBuilder.Entity<Editorial>().ToTable("Editorial");
            modelBuilder.Entity<Recurso>().ToTable("Recurso");
            modelBuilder.Entity<TipoRecurso>().ToTable("TipoRecurso");

            #endregion
        }
    }
}