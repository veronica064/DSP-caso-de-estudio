﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BibliotecaMetropoli.Models;
using BibliotecaMetropoli.Data;

namespace BibliotecaMetropoli.Controllers
{
    /// <summary>
    /// Controlador para la gestión de Editoriales
    /// Integrante 5: UI/UX y Consultas Avanzadas
    /// Maneja: Listar, Crear, Editar y Eliminar Editoriales
    /// </summary>
    public class EditorialesController : Controller
    {
        private readonly BibliotecaMetropolisDBContext _context;

        public EditorialesController(BibliotecaMetropolisDBContext context)
        {
            _context = context;
        }

        // GET: Editoriales/ListarEditoriales
        [HttpGet]
        public IActionResult ListarEditoriales()
        {
            var editoriales = _context.Editorial
                .Include(e => e.Recursos)
                .OrderBy(e => e.Nombre)
                .ToList();

            return View(editoriales);
        }

        // GET: Editoriales/CrearEditorial
        [HttpGet]
        public IActionResult CrearEditorial()
        {
            return View("FormularioEditorial", new Editorial());
        }

        // POST: Editoriales/CrearEditorial
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CrearEditorial(Editorial editorial)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Validar que no exista una editorial con el mismo nombre
                    var editorialExistente = _context.Editorial
                        .FirstOrDefault(e => e.Nombre.ToLower() == editorial.Nombre.ToLower());

                    if (editorialExistente != null)
                    {
                        ModelState.AddModelError("", "Ya existe una editorial con este nombre.");
                        return View("FormularioEditorial", editorial);
                    }

                    _context.Editorial.Add(editorial);
                    _context.SaveChanges();

                    TempData["SuccessMessage"] = $"Editorial '{editorial.Nombre}' registrada exitosamente.";
                    return RedirectToAction("ListarEditoriales");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error al registrar la editorial: {ex.Message}");
                }
            }

            return View("FormularioEditorial", editorial);
        }

        // GET: Editoriales/EditarEditorial/5
        [HttpGet]
        public IActionResult EditarEditorial(int id)
        {
            var editorial = _context.Editorial.Find(id);

            if (editorial == null)
            {
                TempData["ErrorMessage"] = "Editorial no encontrada.";
                return RedirectToAction("ListarEditoriales");
            }

            return View("FormularioEditorial", editorial);
        }

        // POST: Editoriales/EditarEditorial/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarEditorial(Editorial editorial)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Validar que no exista otra editorial con el mismo nombre
                    var editorialExistente = _context.Editorial
                        .FirstOrDefault(e => e.IdEdit != editorial.IdEdit &&
                                           e.Nombre.ToLower() == editorial.Nombre.ToLower());

                    if (editorialExistente != null)
                    {
                        ModelState.AddModelError("", "Ya existe otra editorial con este nombre.");
                        return View("FormularioEditorial", editorial);
                    }

                    _context.Editorial.Update(editorial);
                    _context.SaveChanges();

                    TempData["SuccessMessage"] = $"Editorial '{editorial.Nombre}' actualizada exitosamente.";
                    return RedirectToAction("ListarEditoriales");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error al actualizar la editorial: {ex.Message}");
                }
            }

            return View("FormularioEditorial", editorial);
        }

        // POST: Editoriales/EliminarEditorial/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EliminarEditorial(int id)
        {
            try
            {
                var editorial = _context.Editorial
                    .Include(e => e.Recursos)
                    .FirstOrDefault(e => e.IdEdit == id);

                if (editorial == null)
                {
                    TempData["ErrorMessage"] = "Editorial no encontrada.";
                    return RedirectToAction("ListarEditoriales");
                }

                // Verificar si la editorial tiene recursos asociados
                if (editorial.Recursos != null && editorial.Recursos.Any())
                {
                    TempData["ErrorMessage"] = $"No se puede eliminar la editorial '{editorial.Nombre}' porque tiene {editorial.Recursos.Count} recursos asociados.";
                    return RedirectToAction("ListarEditoriales");
                }

                _context.Editorial.Remove(editorial);
                _context.SaveChanges();

                TempData["SuccessMessage"] = $"Editorial '{editorial.Nombre}' eliminada exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error al eliminar la editorial: {ex.Message}";
            }

            return RedirectToAction("ListarEditoriales");
        }
    }
}