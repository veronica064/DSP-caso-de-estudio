﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BibliotecaMetropoli.Models;
using BibliotecaMetropoli.Data;

namespace BibliotecaMetropoli.Controllers
{
    /// <summary>
    /// Controlador para la gestión de Recursos (Materiales)
    /// Integrante 5: UI/UX y Consultas Avanzadas
    /// Maneja: Registro, Búsqueda Avanzada y Listado con Filtros
    /// 
    /// Integrantes del Equipo:
    /// - [Nombre Integrante 1] - Arquitecto y Gestor
    /// - [Nombre Integrante 2] - Especialista en SQL Server
    /// - [Nombre Integrante 3] - Especialista en Entity Framework
    /// - [Nombre Integrante 4] - Especialista en Lógica de Negocio
    /// - [Nombre Integrante 5] - Especialista en UI/UX y Consultas
    /// </summary>
    public class RecursosController : Controller
    {
        private readonly BibliotecaMetropolisDBContext _context;

        public RecursosController(BibliotecaMetropolisDBContext context)
        {
            _context = context;
        }

        #region REGISTRO DE MATERIALES

        // GET: Recursos/RegistrarMaterial
        [HttpGet]
        public IActionResult RegistrarMaterial()
        {
            var viewModel = new RecursoViewModel
            {
                // Cargar listas para los dropdowns
                Paises = _context.Pais
                    .OrderBy(p => p.Nombre)
                    .Select(p => new SelectListItem
                    {
                        Value = p.IdPais.ToString(),
                        Text = p.Nombre
                    }).ToList(),

                TiposRecurso = _context.TipoRecurso
                    .OrderBy(t => t.Nombre)
                    .Select(t => new SelectListItem
                    {
                        Value = t.IdTipoR.ToString(),
                        Text = t.Nombre
                    }).ToList(),

                Editoriales = _context.Editorial
                    .OrderBy(e => e.Nombre)
                    .Select(e => new SelectListItem
                    {
                        Value = e.IdEdit.ToString(),
                        Text = e.Nombre
                    }).ToList(),

                Autores = _context.Autor
                    .OrderBy(a => a.Apellidos)
                    .ThenBy(a => a.Nombres)
                    .Select(a => new SelectListItem
                    {
                        Value = a.IdAutor.ToString(),
                        Text = $"{a.Nombres} {a.Apellidos}"
                    }).ToList()
            };

            return View(viewModel);
        }

        // POST: Recursos/RegistrarMaterial
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RegistrarMaterial(RecursoViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Validar que se haya seleccionado al menos un autor
                    if (viewModel.AutoresSeleccionados == null || !viewModel.AutoresSeleccionados.Any())
                    {
                        ModelState.AddModelError("", "Debes seleccionar al menos un autor.");
                        CargarListasDropdown(viewModel);
                        return View(viewModel);
                    }

                    // Validar que se haya marcado un autor principal
                    if (!viewModel.AutorPrincipalId.HasValue)
                    {
                        ModelState.AddModelError("", "Debes marcar un autor como principal.");
                        CargarListasDropdown(viewModel);
                        return View(viewModel);
                    }

                    // Validar que el autor principal esté entre los seleccionados
                    if (!viewModel.AutoresSeleccionados.Contains(viewModel.AutorPrincipalId.Value))
                    {
                        ModelState.AddModelError("", "El autor principal debe estar entre los autores seleccionados.");
                        CargarListasDropdown(viewModel);
                        return View(viewModel);
                    }

                    // Crear el recurso
                    var recurso = new Recurso
                    {
                        Titulo = viewModel.Titulo,
                        annopublic = viewModel.AnnoPublic,
                        Edicion = viewModel.Edicion,
                        IdPais = viewModel.IdPais,
                        IdTipoR = viewModel.IdTipoR,
                        IdEdit = viewModel.IdEdit, // Puede ser null para Tesis
                        PalabrasBusqueda = viewModel.PalabrasBusqueda,
                        Palabrasbusqueda = viewModel.PalabrasBusqueda, // Por compatibilidad
                        Descripcion = viewModel.Descripcion
                    };

                    _context.Recurso.Add(recurso);
                    _context.SaveChanges(); // Guardar para obtener el IdRec

                    // Asociar autores al recurso
                    foreach (var autorId in viewModel.AutoresSeleccionados)
                    {
                        var autorRecurso = new AutoresRecurso
                        {
                            IdRec = recurso.IdRec,
                            IdAutor = autorId,
                            EsPrincipal = autorId == viewModel.AutorPrincipalId.Value
                        };

                        _context.AutoresRecurso.Add(autorRecurso);
                    }

                    _context.SaveChanges();

                    TempData["SuccessMessage"] = $"Material '{recurso.Titulo}' registrado exitosamente.";
                    return RedirectToAction("ListarMateriales");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error al registrar el material: {ex.Message}");
                }
            }

            // Si hay errores, recargar las listas
            CargarListasDropdown(viewModel);
            return View(viewModel);
        }

        #endregion

        #region BÚSQUEDA AVANZADA

        // GET: Recursos/BuscarRecursos
        [HttpGet]
        public IActionResult BuscarRecursos(string autor, string palabrasClave, int? idEditorial, int? idTipoRecurso)
        {
            var viewModel = new BusquedaViewModel
            {
                Autor = autor,
                PalabrasClave = palabrasClave,
                IdEditorial = idEditorial,
                IdTipoRecurso = idTipoRecurso,

                // Cargar listas para los dropdowns
                Editoriales = _context.Editorial
                    .OrderBy(e => e.Nombre)
                    .Select(e => new SelectListItem
                    {
                        Value = e.IdEdit.ToString(),
                        Text = e.Nombre
                    }).ToList(),

                TiposRecurso = _context.TipoRecurso
                    .OrderBy(t => t.Nombre)
                    .Select(t => new SelectListItem
                    {
                        Value = t.IdTipoR.ToString(),
                        Text = t.Nombre
                    }).ToList()
            };

            // Si hay criterios de búsqueda, ejecutar la consulta
            if (!string.IsNullOrWhiteSpace(autor) ||
                !string.IsNullOrWhiteSpace(palabrasClave) ||
                idEditorial.HasValue ||
                idTipoRecurso.HasValue)
            {
                var query = _context.Recurso
                    .Include(r => r.TipoRecurso)
                    .Include(r => r.Editorial)
                    .Include(r => r.Pais)
                    .Include(r => r.AutoresRecurso)
                        .ThenInclude(ar => ar.Autor)
                    .AsQueryable();

                // Filtrar por autor (busca en nombres o apellidos)
                if (!string.IsNullOrWhiteSpace(autor))
                {
                    query = query.Where(r => r.AutoresRecurso.Any(ar =>
                        ar.Autor.Nombres.Contains(autor) ||
                        ar.Autor.Apellidos.Contains(autor)));
                }

                // Filtrar por palabras clave
                if (!string.IsNullOrWhiteSpace(palabrasClave))
                {
                    query = query.Where(r => r.PalabrasBusqueda.Contains(palabrasClave) ||
                                           r.Palabrasbusqueda.Contains(palabrasClave) ||
                                           r.Titulo.Contains(palabrasClave));
                }

                // Filtrar por editorial
                if (idEditorial.HasValue)
                {
                    query = query.Where(r => r.IdEdit == idEditorial.Value);
                }

                // Filtrar por tipo de recurso
                if (idTipoRecurso.HasValue)
                {
                    query = query.Where(r => r.IdTipoR == idTipoRecurso.Value);
                }

                // Ejecutar consulta y mapear a DTO
                viewModel.Resultados = query
                    .OrderBy(r => r.Titulo)
                    .Select(r => new RecursoResultadoDto
                    {
                        IdRec = r.IdRec,
                        Titulo = r.Titulo,
                        AnnoPublic = r.annopublic,
                        TipoRecurso = r.TipoRecurso.Nombre,
                        Editorial = r.Editorial != null ? r.Editorial.Nombre : null,
                        Autores = string.Join(", ", r.AutoresRecurso
                            .Select(ar => $"{ar.Autor.Nombres} {ar.Autor.Apellidos}")),
                        AutorPrincipal = r.AutoresRecurso
                            .Where(ar => ar.EsPrincipal)
                            .Select(ar => $"{ar.Autor.Nombres} {ar.Autor.Apellidos}")
                            .FirstOrDefault(),
                        PalabrasBusqueda = r.PalabrasBusqueda ?? r.Palabrasbusqueda,
                        Pais = r.Pais.Nombre
                    }).ToList();
            }

            return View("BusquedaAvanzada", viewModel);
        }

        #endregion

        #region LISTADO CON FILTROS

        // GET: Recursos/ListarMateriales
        [HttpGet]
        public IActionResult ListarMateriales(int? idTipoRecurso, int? aniosAntiguedad)
        {
            var viewModel = new ListadoMaterialesViewModel
            {
                IdTipoRecurso = idTipoRecurso,
                AniosAntiguedad = aniosAntiguedad,

                // Cargar tipos de recurso para el dropdown
                TiposRecurso = _context.TipoRecurso
                    .OrderBy(t => t.Nombre)
                    .Select(t => new SelectListItem
                    {
                        Value = t.IdTipoR.ToString(),
                        Text = t.Nombre,
                        Selected = t.IdTipoR == idTipoRecurso
                    }).ToList()
            };

            // Consulta base
            var query = _context.Recurso
                .Include(r => r.TipoRecurso)
                .Include(r => r.Editorial)
                .Include(r => r.Pais)
                .Include(r => r.AutoresRecurso)
                    .ThenInclude(ar => ar.Autor)
                .AsQueryable();

            // Filtrar por tipo de recurso
            if (idTipoRecurso.HasValue)
            {
                query = query.Where(r => r.IdTipoR == idTipoRecurso.Value);
                viewModel.TipoSeleccionado = _context.TipoRecurso
                    .Where(t => t.IdTipoR == idTipoRecurso.Value)
                    .Select(t => t.Nombre)
                    .FirstOrDefault();
            }

            // Filtrar por antigüedad (hasta X años atrás)
            if (aniosAntiguedad.HasValue)
            {
                var anioMinimo = DateTime.Now.Year - aniosAntiguedad.Value;
                query = query.Where(r => r.annopublic >= anioMinimo);
            }

            // Ejecutar consulta y mapear a DTO
            var anioActual = DateTime.Now.Year;
            viewModel.Materiales = query
                .OrderByDescending(r => r.annopublic)
                .ThenBy(r => r.Titulo)
                .Select(r => new RecursoListadoDto
                {
                    IdRec = r.IdRec,
                    Titulo = r.Titulo,
                    AnnoPublic = r.annopublic,
                    Edicion = r.Edicion,
                    TipoRecurso = r.TipoRecurso.Nombre,
                    Editorial = r.Editorial != null ? r.Editorial.Nombre : null,
                    Autores = string.Join(", ", r.AutoresRecurso
                        .Select(ar => $"{ar.Autor.Nombres} {ar.Autor.Apellidos}")),
                    Pais = r.Pais.Nombre,
                    Descripcion = r.Descripcion,
                    Antiguedad = anioActual - r.annopublic
                }).ToList();

            viewModel.TotalMateriales = viewModel.Materiales.Count;

            return View("ListadoMateriales", viewModel);
        }

        #endregion

        #region MÉTODOS AUXILIARES

        private void CargarListasDropdown(RecursoViewModel viewModel)
        {
            viewModel.Paises = _context.Pais
                .OrderBy(p => p.Nombre)
                .Select(p => new SelectListItem
                {
                    Value = p.IdPais.ToString(),
                    Text = p.Nombre
                }).ToList();

            viewModel.TiposRecurso = _context.TipoRecurso
                .OrderBy(t => t.Nombre)
                .Select(t => new SelectListItem
                {
                    Value = t.IdTipoR.ToString(),
                    Text = t.Nombre
                }).ToList();

            viewModel.Editoriales = _context.Editorial
                .OrderBy(e => e.Nombre)
                .Select(e => new SelectListItem
                {
                    Value = e.IdEdit.ToString(),
                    Text = e.Nombre
                }).ToList();

            viewModel.Autores = _context.Autor
                .OrderBy(a => a.Apellidos)
                .ThenBy(a => a.Nombres)
                .Select(a => new SelectListItem
                {
                    Value = a.IdAutor.ToString(),
                    Text = $"{a.Nombres} {a.Apellidos}"
                }).ToList();
        }

        #endregion
    }
}