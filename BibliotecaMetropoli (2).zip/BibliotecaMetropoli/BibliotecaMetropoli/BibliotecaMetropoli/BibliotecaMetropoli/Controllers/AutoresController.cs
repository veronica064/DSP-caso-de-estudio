﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BibliotecaMetropoli.Models;
using BibliotecaMetropoli.Data;

namespace BibliotecaMetropoli.Controllers
{
    /// <summary>
    /// Controlador para la gestión de Autores
    /// Integrante 5: UI/UX y Consultas Avanzadas
    /// Maneja: Listar, Crear, Editar y Eliminar Autores
    /// </summary>
    public class AutoresController : Controller
    {
        private readonly BibliotecaMetropolisDBContext _context;

        public AutoresController(BibliotecaMetropolisDBContext context)
        {
            _context = context;
        }

        // GET: Autores/ListarAutores
        [HttpGet]
        public IActionResult ListarAutores()
        {
            var autores = _context.Autor
                .OrderBy(a => a.Apellidos)
                .ThenBy(a => a.Nombres)
                .ToList();

            return View(autores);
        }

        // GET: Autores/CrearAutor
        [HttpGet]
        public IActionResult CrearAutor()
        {
            return View("FormularioAutor", new Autor());
        }

        // POST: Autores/CrearAutor
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CrearAutor(Autor autor)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Validar que no exista un autor con el mismo nombre completo
                    var autorExistente = _context.Autor
                        .FirstOrDefault(a => a.Nombres.ToLower() == autor.Nombres.ToLower() &&
                                           a.Apellidos.ToLower() == autor.Apellidos.ToLower());

                    if (autorExistente != null)
                    {
                        ModelState.AddModelError("", "Ya existe un autor con este nombre completo.");
                        return View("FormularioAutor", autor);
                    }

                    _context.Autor.Add(autor);
                    _context.SaveChanges();

                    TempData["SuccessMessage"] = $"Autor '{autor.Nombres} {autor.Apellidos}' registrado exitosamente.";
                    return RedirectToAction("ListarAutores");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error al registrar el autor: {ex.Message}");
                }
            }

            return View("FormularioAutor", autor);
        }

        // GET: Autores/EditarAutor/5
        [HttpGet]
        public IActionResult EditarAutor(int id)
        {
            var autor = _context.Autor.Find(id);

            if (autor == null)
            {
                TempData["ErrorMessage"] = "Autor no encontrado.";
                return RedirectToAction("ListarAutores");
            }

            return View("FormularioAutor", autor);
        }

        // POST: Autores/EditarAutor/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditarAutor(Autor autor)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Validar que no exista otro autor con el mismo nombre completo
                    var autorExistente = _context.Autor
                        .FirstOrDefault(a => a.IdAutor != autor.IdAutor &&
                                           a.Nombres.ToLower() == autor.Nombres.ToLower() &&
                                           a.Apellidos.ToLower() == autor.Apellidos.ToLower());

                    if (autorExistente != null)
                    {
                        ModelState.AddModelError("", "Ya existe otro autor con este nombre completo.");
                        return View("FormularioAutor", autor);
                    }

                    _context.Autor.Update(autor);
                    _context.SaveChanges();

                    TempData["SuccessMessage"] = $"Autor '{autor.Nombres} {autor.Apellidos}' actualizado exitosamente.";
                    return RedirectToAction("ListarAutores");
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error al actualizar el autor: {ex.Message}");
                }
            }

            return View("FormularioAutor", autor);
        }

        // POST: Autores/EliminarAutor/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EliminarAutor(int id)
        {
            try
            {
                var autor = _context.Autor
                    .Include(a => a.AutoresRecurso)
                    .FirstOrDefault(a => a.IdAutor == id);

                if (autor == null)
                {
                    TempData["ErrorMessage"] = "Autor no encontrado.";
                    return RedirectToAction("ListarAutores");
                }

                // Verificar si el autor tiene recursos asociados
                if (autor.AutoresRecurso != null && autor.AutoresRecurso.Any())
                {
                    TempData["ErrorMessage"] = $"No se puede eliminar el autor '{autor.Nombres} {autor.Apellidos}' porque tiene recursos asociados.";
                    return RedirectToAction("ListarAutores");
                }

                _context.Autor.Remove(autor);
                _context.SaveChanges();

                TempData["SuccessMessage"] = $"Autor '{autor.Nombres} {autor.Apellidos}' eliminado exitosamente.";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error al eliminar el autor: {ex.Message}";
            }

            return RedirectToAction("ListarAutores");
        }
    }
}