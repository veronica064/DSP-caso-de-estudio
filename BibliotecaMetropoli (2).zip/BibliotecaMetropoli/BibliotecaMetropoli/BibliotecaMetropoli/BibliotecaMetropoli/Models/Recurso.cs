﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BibliotecaMetropoli.Models
{
    public class Recurso
    {
        public int IdRec { get; set; }
        [Required]
        public int IdTipoR { get; set; }

        [Required(ErrorMessage = "El título es obligatorio.")]
        public string Titulo { get; set; } = string.Empty;

        [Required(ErrorMessage = "El año de publicación es obligatorio.")]
        public int annopublic { get; set; }

        [Required(ErrorMessage = "La edición es obligatoria.")]
        public string Edicion { get; set; } = string.Empty;

        // FK a Editorial (opcional para Tesis)
        public int? IdEdit { get; set; }
        public virtual Editorial? Editorial { get; set; }
        [StringLength(1000)]
        public string Descripcion { get; set; }

        [StringLength(500)]
        public string PalabrasBusqueda { get; set; }

        // FK a Pais
        [Required(ErrorMessage = "El país es obligatorio.")]
        public int IdPais { get; set; }
        public virtual Pais Pais { get; set; } = null!;

        // Campo de palabras clave (como en tu ER)
        public string Palabrasbusqueda { get; set; } = string.Empty;

        [ForeignKey("IdTipoR")]
        public virtual TipoRecurso TipoRecurso { get; set; }

        // Relación muchos a muchos con autores
        public virtual ICollection<AutoresRecurso> AutoresRecurso { get; set; } = new HashSet<AutoresRecurso>();

    }
}
