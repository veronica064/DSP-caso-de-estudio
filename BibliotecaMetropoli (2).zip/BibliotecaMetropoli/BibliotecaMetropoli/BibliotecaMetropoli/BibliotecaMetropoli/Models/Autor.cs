﻿using System.ComponentModel.DataAnnotations;

namespace BibliotecaMetropoli.Models
{
    public class Autor
    {
        public int IdAutor { get; set; }

        [Required(ErrorMessage = "Los nombres del autor son obligatorios. Por favor ingresa los nombres completos")]
        public string Nombres { get; set; } = string.Empty;

        [Required(ErrorMessage = "Los apellidos del autor son obligatorios. Por favor ingresa los apellidos completos")]
        public string Apellidos { get; set; } = string.Empty;

        public virtual ICollection<AutoresRecurso> AutoresRecurso { get; set; } = new HashSet<AutoresRecurso>();
        public virtual ICollection<Recurso> Recursos { get; set; }
    }
}
