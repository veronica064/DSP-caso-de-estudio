﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace BibliotecaMetropoli.Models
{
    /// <summary>
    /// ViewModel para la búsqueda avanzada de recursos
    /// Integrante 5: UI/UX y Consultas Avanzadas
    /// Permite buscar por 1 a 4 campos simultáneamente
    /// </summary>
    public class BusquedaViewModel
    {
        // Criterios de búsqueda
        public string? Autor { get; set; }
        public string? PalabrasClave { get; set; }
        public int? IdEditorial { get; set; }
        public int? IdTipoRecurso { get; set; }

        // Listas para dropdowns
        public List<SelectListItem>? Editoriales { get; set; }
        public List<SelectListItem>? TiposRecurso { get; set; }

        // Resultados de la búsqueda
        public List<RecursoResultadoDto>? Resultados { get; set; }
    }

    /// <summary>
    /// DTO para mostrar los resultados de búsqueda
    /// </summary>
    public class RecursoResultadoDto
    {
        public int IdRec { get; set; }
        public string Titulo { get; set; } = string.Empty;
        public int AnnoPublic { get; set; }
        public string TipoRecurso { get; set; } = string.Empty;
        public string? Editorial { get; set; }
        public string Autores { get; set; } = string.Empty;
        public string? AutorPrincipal { get; set; }
        public string? PalabrasBusqueda { get; set; }
        public string Pais { get; set; } = string.Empty;
    }
}