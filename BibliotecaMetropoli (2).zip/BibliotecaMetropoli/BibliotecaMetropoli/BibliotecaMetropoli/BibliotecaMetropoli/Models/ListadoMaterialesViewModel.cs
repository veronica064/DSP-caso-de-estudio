﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace BibliotecaMetropoli.Models
{
    /// <summary>
    /// ViewModel para el listado de materiales con filtros
    /// Integrante 5: UI/UX y Consultas Avanzadas
    /// Permite filtrar por tipo de recurso y antigüedad (hasta 10 años)
    /// </summary>
    public class ListadoMaterialesViewModel
    {
        // Filtros
        public int? IdTipoRecurso { get; set; }
        public int? AniosAntiguedad { get; set; }

        // Listas para dropdowns
        public List<SelectListItem>? TiposRecurso { get; set; }

        // Resultados
        public List<RecursoListadoDto>? Materiales { get; set; }

        // Estadísticas
        public int TotalMateriales { get; set; }
        public string? TipoSeleccionado { get; set; }
    }

    /// <summary>
    /// DTO para el listado de materiales
    /// </summary>
    public class RecursoListadoDto
    {
        public int IdRec { get; set; }
        public string Titulo { get; set; } = string.Empty;
        public int AnnoPublic { get; set; }
        public string Edicion { get; set; } = string.Empty;
        public string TipoRecurso { get; set; } = string.Empty;
        public string? Editorial { get; set; }
        public string Autores { get; set; } = string.Empty;
        public string Pais { get; set; } = string.Empty;
        public string? Descripcion { get; set; }
        public int Antiguedad { get; set; } // Años desde publicación
    }
}