﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BibliotecaMetropoli.Models
{
    /// <summary>
    /// ViewModel para el formulario de registro de materiales
    /// Integrante 5: UI/UX y Consultas Avanzadas
    /// </summary>
    public class RecursoViewModel
    {
        [Required(ErrorMessage = "El título es obligatorio")]
        [StringLength(255)]
        public string Titulo { get; set; } = string.Empty;

        [Required(ErrorMessage = "El año de publicación es obligatorio")]
        [Range(1500, 2100, ErrorMessage = "Ingresa un año válido")]
        public int AnnoPublic { get; set; }

        [Required(ErrorMessage = "La edición es obligatoria")]
        [StringLength(50)]
        public string Edicion { get; set; } = string.Empty;

        [Required(ErrorMessage = "Debes seleccionar un país")]
        public int IdPais { get; set; }

        [Required(ErrorMessage = "Debes seleccionar un tipo de recurso")]
        public int IdTipoR { get; set; }

        // Opcional para Tesis (no requiere editorial)
        public int? IdEdit { get; set; }

        [StringLength(500)]
        [Display(Name = "Palabras clave")]
        public string PalabrasBusqueda { get; set; } = string.Empty;

        [StringLength(1000)]
        [Display(Name = "Descripción")]
        public string Descripcion { get; set; } = string.Empty;

        // Lista de IDs de autores seleccionados
        public List<int> AutoresSeleccionados { get; set; } = new List<int>();

        // ID del autor principal
        public int? AutorPrincipalId { get; set; }

        // Listas para los dropdowns (se llenan desde el controlador)
        public List<SelectListItem>? Paises { get; set; }
        public List<SelectListItem>? TiposRecurso { get; set; }
        public List<SelectListItem>? Editoriales { get; set; }
        public List<SelectListItem>? Autores { get; set; }
    }
}